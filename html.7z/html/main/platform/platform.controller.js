﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainPlatformController', MainPlatformController);

    MainPlatformController.$inject = ['$rootScope'];
    function MainPlatformController($rootScope) {
        var vm = this;

    }

})();