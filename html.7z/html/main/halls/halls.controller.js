﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainHallsController', MainHallsController);

    MainHallsController.$inject = ['$rootScope'];
    function MainHallsController($rootScope) {
        var vm = this;

    }

})();