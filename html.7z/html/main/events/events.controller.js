﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainEventsController', MainEventsController);

    MainEventsController.$inject = ['$rootScope'];
    function MainEventsController($rootScope) {
        var vm = this;

    }

})();