(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainPersonaCreateSchemaController', MainPersonaCreateSchemaController);

    MainPersonaCreateSchemaController.$inject = ['$scope', '$stateParams'];

    function MainPersonaCreateSchemaController($scope, $stateParams) {
        var vm = this;
    }
})();