﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainRoleController', MainRoleController);

    MainRoleController.$inject = ['$rootScope'];
    function MainRoleController($rootScope) {
        var vm = this;

    }

})();